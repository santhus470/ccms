import 'package:flutter_riverpod/flutter_riverpod.dart';

class PickedFilesNotofier extends StateNotifier<List<String>> {
  PickedFilesNotofier() : super([]);

  void addListOfPath(List<String> paths) {
    state = [for (final path in paths) path];
    print(state);
  }
}

final pickedFileListProvider =
    StateNotifierProvider<PickedFilesNotofier, List<String>>(
        (ref) => PickedFilesNotofier());
