import 'package:ccms/features/presentation/widgets/contaIner_heading.dart';
import 'package:ccms/providers/selected_imf_file_path_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ImageListPArtWidget extends ConsumerStatefulWidget {
  const ImageListPArtWidget({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _ImageListPArtWidgetState();
}

class _ImageListPArtWidgetState extends ConsumerState<ImageListPArtWidget> {
  @override
  Widget build(BuildContext context) {
    List<String> paths = ref.watch(pickedFileListProvider);
    return Stack(
      children: [
        Container(
          color: Colors.white10,
          child: Column(
            children: [
              const ContainerHeadingWidget(title: 'Image List'),
              Expanded(
                child: ListView(
                    children: paths.map((e) {
                  return Container(
                    color: Colors.black38,
                    margin: const EdgeInsets.all(10),
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: Row(
                      children: [
                        const Icon(Icons.image),
                        const SizedBox(width: 10),
                        Expanded(child: Text(e.split('\\').last)),
                        const SizedBox(width: 10),
                        IconButton.filledTonal(
                            onPressed: () {},
                            icon: const Icon(Icons.delete,
                                size: 18, color: Colors.redAccent)),
                        // const SizedBox(width: 20),
                        // const Icon(
                        //   Icons.arrow_forward_ios,
                        //   size: 18,
                        //   color: Colors.yellow,
                        // ),
                      ],
                    ),
                  );
                }).toList()),
              )
            ],
          ),
        ),
        Positioned(
          bottom: 20,
          right: 10,
          child: FloatingActionButton.extended(
            onPressed: () {},
            label: const Text('Save All Images'),
            icon: const Icon(Icons.add),
          ),
        )
      ],
    );
  }
}
