import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class CCMSMenubar extends ConsumerStatefulWidget {
  const CCMSMenubar({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _CCMSMenubarState();
}

class _CCMSMenubarState extends ConsumerState<CCMSMenubar> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
