

from PyPDF2 import PdfFileReader, PdfFileWriter


def compress_pdf(filePath):
   reader = PdfFileReader(filePath)
   writer = PdfFileWriter()
   for page in reader.pages:    
      writer.addPage(page.com)


